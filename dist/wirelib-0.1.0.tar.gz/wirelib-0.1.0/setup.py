# -*- coding: utf-8 -*-
from distutils.core import setup

packages = \
['wirelib', 'wirelib.src.wire', 'wirelib.src.wire.utilities']

package_data = \
{'': ['*']}

install_requires = \
['Pygments==2.3',
 'beautifulsoup4==4.7',
 'codecov==2.0.15',
 'colorama==0.4.1',
 'loguru==0.2',
 'pytest-cov==2.6.1',
 'pytest-sugar==0.9.2',
 'pytest-xdist==1.27',
 'pytest==4.4.0',
 'python-dotenv==0.10.1',
 'requests==2.21',
 'selenium==3.141',
 'typeguard==2.3']

setup_kwargs = {
    'name': 'wirelib',
    'version': '0.1.0',
    'description': 'Wrapping Selenium with class',
    'long_description': None,
    'author': 'misterbianco',
    'author_email': 'jayrad.security@protonmail.com',
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.7.1,<4.0.0',
}


setup(**setup_kwargs)
